# FraudShield AI+ — Demo Frontend

🛡️ **FraudShield AI+** is a prototype front-end for a smart investor protection platform that demonstrates key UX flows: advisor verification, fake-app/document scanning, chat NLP checks, and a regulator dashboard feed. This is a **demo-only** static UI; production requires backend, databases, and AI models.

## What is included

- `index.html` — Single-page demo UI
- `style.css` — Styling
- `script.js` — Frontend logic and simulated heuristics
- `README.md` — This file
- `LICENSE` — MIT License
- `.gitignore` — Common ignores

## How to run (VS Code / Local)

1. Unzip the project and open the folder in VS Code.
2. Install and enable **Live Server** extension (recommended).
3. Right-click `index.html` → **Open with Live Server**.

Alternative (command-line):

```bash
# Python 3
python -m http.server 8080
# open http://localhost:8080
```

## Notes
- All checks in this demo are heuristic and placeholder. Real fraud detection needs robust ML models, data sources, and legal review.
- Do not rely on this demo for real-world detection.

## License
MIT
