// Demo registry (mock)
const mockRegistry = [
  { id: 'RA-1001', name: 'Alpha Advisors', valid: true },
  { id: 'RA-1002', name: 'Beta Wealth', valid: true },
  { id: 'RA-2001', name: 'Scam Advisory', valid: false }
];

// Suspicious keywords for NLP demo (simple heuristic)
const suspiciousKeywords = ['guaranteed', 'sure profit', 'no risk', 'get rich', 'allotment', 'insider', 'pump', 'dump'];

// Feed store
let feedItems = [];

// ---------- Advisor Verify ----------
document.getElementById('verifyBtn').addEventListener('click', () => {
  const q = document.getElementById('advisorInput').value.trim();
  const out = document.getElementById('verifyResult');
  if(!q){ out.innerText = 'Enter a name or Reg ID to verify.'; out.style.color=''; return; }
  const found = mockRegistry.find(r => r.id.toLowerCase()===q.toLowerCase() || r.name.toLowerCase().includes(q.toLowerCase()));
  if(found){
    out.innerHTML = `<strong>${found.name}</strong> — Registration: ${found.id} — <span style="color:${found.valid? 'green':'#b91c1c'}">${found.valid? 'REGISTERED':'NOT REGISTERED'}</span>`;
  } else {
    out.innerHTML = 'No exact match found in demo registry. Consider cross-checking with regulator.';
  }
});

// ---------- App / Link Scan ----------
document.getElementById('scanAppBtn').addEventListener('click', ()=> {
  const link = document.getElementById('appLink').value.trim();
  const out = document.getElementById('appResult');
  if(!link){ out.innerText='Paste an app URL or package name.'; return; }
  // Demo heuristics: suspicious if contains 'download', 'free', or short package name with numbers
  const suspicious = /(download|free|crack|hack|cheap|urgent)/i.test(link) || /com\.[a-z0-9]+\.[a-z0-9]+/i.test(link) && link.length<12;
  out.innerHTML = `<strong>Scanned:</strong> ${link}\nResult: <span style="color:${suspicious?'#b91c1c':'green'}">${suspicious? 'SUSPICIOUS':'Looks OK (demo)'}</span>`;
});

// ---------- Document Analyze ----------
document.getElementById('analyzeDoc').addEventListener('click', ()=>{
  const f = document.getElementById('docUpload').files[0];
  const out = document.getElementById('docResult');
  if(!f){ out.innerText='Upload a document first.'; return; }
  const info = { name:f.name, sizeKB: Math.round(f.size/1024), type: f.type || 'unknown', lastModified: new Date(f.lastModified).toISOString() };
  // Demo heuristic: suspicious if filename contains words like 'sebi', 'allotment', 'official' but from unknown source/low size
  const suspicious = /(sebi|allotment|official|certificate|award)/i.test(f.name) && info.sizeKB<50;
  out.innerText = JSON.stringify({ info, suspicious: suspicious ? 'Likely suspicious (demo heuristic)' : 'No immediate red flags (demo)' }, null, 2);
});

// ---------- Media (Deepfake) Analyze ----------
document.getElementById('analyzeMedia').addEventListener('click', ()=>{
  const f = document.getElementById('mediaUpload').files[0];
  const out = document.getElementById('mediaResult');
  if(!f){ out.innerText='Upload audio or video for demo analysis.'; return; }
  // Demo placeholder logic: use file size and extension to create a fake score
  const score = Math.max(0, Math.min(100, Math.round((f.size % 1000000)/10000)));
  const verdict = score>60 ? 'High manipulation risk (demo)' : score>30 ? 'Medium risk (demo)' : 'Low risk (demo)';
  out.innerText = JSON.stringify({ name:f.name, sizeKB:Math.round(f.size/1024), score, verdict }, null, 2);
});

// ---------- Chat Scanner (NLP demo) ----------
document.getElementById('scanChat').addEventListener('click', ()=>{
  const txt = document.getElementById('chatInput').value.toLowerCase();
  const out = document.getElementById('chatResult');
  if(!txt){ out.innerText='Paste messages to scan.'; return; }
  const found = [...new Set(suspiciousKeywords.filter(k=> txt.includes(k)))];
  const risk = found.length>2 ? 'High' : found.length===1 ? 'Low' : found.length>1 ? 'Medium' : 'Minimal';
  out.innerText = JSON.stringify({ risk, matchedKeywords: found, advice: found.length? 'Do not act on these tips. Verify with regulator/registries.' : 'No clear suspicious keywords (demo)' }, null, 2);
  if(found.length){ addFeed({type:'chat', text: txt.slice(0,120) + '...', matched: found}); }
});

document.getElementById('clearChat').addEventListener('click', ()=>{ document.getElementById('chatInput').value=''; document.getElementById('chatResult').innerText=''; });

// ---------- Dashboard Feed ----------
function renderFeed(){
  const container = document.getElementById('feed');
  if(!feedItems.length){ container.innerHTML='<div class="muted">No flags yet (demo).</div>'; return; }
  container.innerHTML = feedItems.map((f, i)=>`<div class="feed-item"><strong>#${i+1}</strong> [${f.type}] ${f.matched? 'Matched: '+f.matched.join(', ') : ''} — <div class="muted">${f.text || f.name || ''}</div></div>`).join('');
}

function addFeed(item){
  feedItems.unshift({ ...item, ts: new Date().toISOString() });
  renderFeed();
}

document.getElementById('simulateFeed').addEventListener('click', ()=>{
  const sample = { type:'pump-and-dump', text:'Viral group pushing XYZ stock - sudden price spike', matched:['pump','dump'] };
  addFeed(sample);
});

document.getElementById('clearFeed').addEventListener('click', ()=>{ feedItems=[]; renderFeed(); });

document.getElementById('exportFeed').addEventListener('click', ()=>{
  if(!feedItems.length){ alert('No feed items to export.'); return; }
  const blob = new Blob([JSON.stringify({ exportedAt:new Date().toISOString(), items: feedItems }, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='fraudshield-feed.json'; a.click(); URL.revokeObjectURL(url);
});

// initial render
renderFeed();
